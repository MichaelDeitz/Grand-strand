/*
 * Copyright (c) 2021 Randall Rowland
 */

packageSearchIndex = [{"l":"All Packages","u":"allpackages-index.html"}];updateSearchResults();