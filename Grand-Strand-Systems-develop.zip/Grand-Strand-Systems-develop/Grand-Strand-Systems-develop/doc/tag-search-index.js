/*
 * Copyright (c) 2021 Randall Rowland
 */

tagSearchIndex = [];updateSearchResults();